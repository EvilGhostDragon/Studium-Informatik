#include <stdio.h>

int main() {
	char sAdd[8] = "World";
	printf("Hello\n%s\n", sAdd);
	return 0;
}